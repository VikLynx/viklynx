package com.example.databaseapp.ui.viewmodel

import android.content.Context.WIFI_SERVICE
import android.graphics.Bitmap
import android.net.wifi.WifiManager
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.example.databaseapp.data.DataDao
import com.example.databaseapp.model.DatabaseModel
import kotlinx.coroutines.launch


class DatabaseViewModel(private val dataDao: DataDao) : ViewModel() {

    private fun insert(item: DatabaseModel) {
        viewModelScope.launch {
            dataDao.insert(item)
        }
    }

    fun getUserItems(name: String): LiveData<List<DatabaseModel>> {
        return dataDao.getUser(name).asLiveData()
    }

    private fun getNewItemEntry(name: String, address: String, poison: Boolean, sweet: Boolean, latitude: String, longitude: String, notes: String, itemPhoto: Bitmap, deviceIp: String, deviceManufacturer: String): DatabaseModel {
        return DatabaseModel(
            name = name,
            address = address,
            poison = poison,
            sweet = sweet,
            latitude = latitude,
            longitude = longitude,
            notes = notes,
            itemPhoto = itemPhoto,
            deviceIp = deviceIp,
            deviceManufacturer = deviceManufacturer
        )
    }

    fun addNewItem(name: String, address: String, poison: Boolean, sweet: Boolean, latitude: String, longitude: String, notes: String, itemPhoto: Bitmap, deviceIp: String, deviceManufacturer: String) {
        val newItem = getNewItemEntry(name, address, poison, sweet, latitude, longitude, notes, itemPhoto, deviceIp, deviceManufacturer)
        insert(newItem)
    }

    fun retrieveItem(id: Int): LiveData<DatabaseModel> {
        return dataDao.getItem(id).asLiveData()
    }

    fun isEntryValid(name: String, address: String, latitude: String, longitude: String): Boolean {
        if (name.isBlank() || address.isBlank() || latitude.isBlank() || longitude.isBlank()) {
            return false
        }
        return true
    }
}

class DatabaseViewModelFactory(private val dataDao: DataDao) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(DatabaseViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return DatabaseViewModel(dataDao) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}