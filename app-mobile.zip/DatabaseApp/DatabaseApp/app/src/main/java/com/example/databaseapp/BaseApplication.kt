package com.example.databaseapp

import android.app.Application
import android.net.wifi.WifiManager
import android.text.format.Formatter
import com.example.databaseapp.data.DatabaseRoom

class BaseApplication : Application() {
    val database: DatabaseRoom by lazy { DatabaseRoom.getDatabase(this) }
}