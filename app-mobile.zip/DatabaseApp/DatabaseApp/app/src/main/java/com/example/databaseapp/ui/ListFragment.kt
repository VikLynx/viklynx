package com.example.databaseapp.ui

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.databaseapp.BaseApplication
import com.example.databaseapp.databinding.FragmentListBinding
import com.example.databaseapp.ui.adapter.MyListAdapter
import com.example.databaseapp.ui.viewmodel.DatabaseViewModel
import com.example.databaseapp.ui.viewmodel.DatabaseViewModelFactory

class ListFragment : Fragment() {

    private val viewModel: DatabaseViewModel by activityViewModels {
        DatabaseViewModelFactory(
            (activity?.application as BaseApplication).database
                .dataDao()
        )
    }

    private var _binding: FragmentListBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val adapter = MyListAdapter {
            val action = ListFragmentDirections.actionListFragmentToListDetailFragment(it.id.toInt())
            this.findNavController().navigate(action)
        }
        binding.recyclerView.adapter = adapter
        binding.searchButton.setOnClickListener {
            val users = viewModel.getUserItems(binding.nameInput.text.toString())
            users.observe(this.viewLifecycleOwner) {
                    items -> items.let { adapter.submitList(it) }
            }
        }
        binding.recyclerView.layoutManager = LinearLayoutManager(this.context)

    }

}