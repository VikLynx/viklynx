package com.example.databaseapp.ui

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.example.databaseapp.BaseApplication
import com.example.databaseapp.R
import com.example.databaseapp.databinding.FragmentListDetailBinding
import com.example.databaseapp.model.DatabaseModel
import com.example.databaseapp.ui.viewmodel.DatabaseViewModel
import com.example.databaseapp.ui.viewmodel.DatabaseViewModelFactory
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.MapView
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions

class ListDetailFragment: Fragment(), OnMapReadyCallback {
    private val viewModel: DatabaseViewModel by activityViewModels {
        DatabaseViewModelFactory(
            (activity?.application as BaseApplication).database.dataDao()
        )
    }

    lateinit var item: DatabaseModel
    private var _binding: FragmentListDetailBinding? = null
    private val binding get() = _binding!!
    lateinit var mapFragment: MapView

    private val navigationArgs: ListDetailFragmentArgs by navArgs()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentListDetailBinding.inflate(inflater, container, false)
        return binding.root
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val id = navigationArgs.itemId
        viewModel.retrieveItem(id).observe(this.viewLifecycleOwner) {
                selectedItem -> item = selectedItem
            bind(item)
        }
        mapFragment = requireView().findViewById(R.id.map)
        mapFragment.onCreate(null)
        mapFragment.onResume()
        binding.backButton.setOnClickListener {
            findNavController().navigate(R.id.action_listDetailFragment_to_startFragment)
        }
    }

    @SuppressLint("SetTextI18n")
    private fun bind(item: DatabaseModel) {
        binding.apply {
            userName.text = item.name
            address.text = item.address
            if (item.poison) {
                hazardousWaste.text = "tak"
            } else {
                hazardousWaste.text = "nie"
            }
            if (item.sweet) {
                identified.text = "tak"
            } else {
                identified.text = "nie"
            }
            if (item.notes.isBlank()) {
                notes.text = "Brak uwag"
            } else {
                notes.text = item.notes
            }
            pickedImage.setImageBitmap(item.itemPhoto)
        }
        mapFragment.getMapAsync(this)
        mapFragment.getMapAsync(this)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onMapReady(p0: GoogleMap) {
        val latitude = item.latitude.toDouble()
        val longitude = item.longitude.toDouble()
        val myLocation = LatLng(latitude, longitude)
        p0.addMarker(
            MarkerOptions()
                .position(myLocation)
                .title("My location")
        )
        p0.moveCamera(CameraUpdateFactory.newLatLng(myLocation))
        p0.moveCamera(CameraUpdateFactory.zoomTo(10F))
    }

}

