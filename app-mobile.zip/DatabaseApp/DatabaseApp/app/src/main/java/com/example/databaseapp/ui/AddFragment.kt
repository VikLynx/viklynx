package com.example.databaseapp.ui

import android.annotation.SuppressLint
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.drawToBitmap
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import com.example.databaseapp.BaseApplication
import com.example.databaseapp.R
import com.example.databaseapp.data.ResourceProvider
import com.example.databaseapp.databinding.FragmentAddBinding
import com.example.databaseapp.ui.viewmodel.DatabaseViewModel
import com.example.databaseapp.ui.viewmodel.DatabaseViewModelFactory
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.MapView
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.vmadalin.easypermissions.EasyPermissions

class AddFragment : Fragment(), EasyPermissions.PermissionCallbacks, OnMapReadyCallback {

    companion object {
        const val PERMISSION_LOCATION_REQUEST_CODE = 1
    }

    private lateinit var repository: ResourceProvider
    private lateinit var binding: FragmentAddBinding
    private lateinit var fusedLocationProviderClient: FusedLocationProviderClient
    lateinit var mapFragment: MapView
    private var imageName: String = ""
    private val getContent = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        binding.pickedImage.setImageURI(uri)
        imageName = getFileName(requireContext(), uri!!)
        binding.photoName.text = imageName
    }

    private val viewModel: DatabaseViewModel by activityViewModels {
        DatabaseViewModelFactory(
            (activity?.application as BaseApplication).database
                .dataDao()
        )
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentAddBinding.inflate(inflater, container, false)
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(requireContext())
        repository = ResourceProvider(requireContext())

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.run {  }
        mapFragment = requireView().findViewById(R.id.map)
        mapFragment.onCreate(null)
        mapFragment.onResume()
        getUserLocation()
        binding.saveBtn.setOnClickListener {
            val deviceIp = repository.getIp()
            binding.deviceIp.setText(deviceIp)
            val deviceManufacturer = repository.getDeviceInfo()
            binding.deviceManufacturer.setText(deviceManufacturer)
            addNewItem()
        }
        binding.pickPhotoImageButton.setOnClickListener {
            pickImageFromGallery()
        }
    }

    private fun pickImageFromGallery() {
        getContent.launch("image/*")
    }

    @SuppressLint("Range")
    private fun getFileName(context: Context, uri: Uri): String {

        if (uri.scheme == "content") {
            val cursor = context.contentResolver.query(uri, null, null, null, null)
            cursor!!.use {
                if(cursor.moveToFirst()) {
                    return cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME))
                }
            }
        }

        return uri.path?.substring(uri.path!!.lastIndexOf('/') + 1) ?: "image not picked"
    }



    private fun isEntryValid(): Boolean {
        return viewModel.isEntryValid(
            binding.nameInput.text.toString(),
            binding.locationAddressInput.text.toString(),
            binding.xInput.text.toString(),
            binding.yInput.text.toString()
        )
    }

    private fun addNewItem() {
        if (isEntryValid()) {
            viewModel.addNewItem(
                binding.nameInput.text.toString(),
                binding.locationAddressInput.text.toString(),
                binding.hazardousWaste.isChecked,
                binding.noIdentification.isChecked,
                binding.xInput.text.toString(),
                binding.yInput.text.toString(),
                binding.notesInput.text.toString(),
                binding.pickedImage.drawToBitmap(),
                binding.deviceIp.text.toString(),
                binding.deviceManufacturer.text.toString()
            )
            Navigation.findNavController(requireView())
                .navigate(R.id.action_addFragment_to_startFragment)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        binding.xInput.setText("")
        binding.yInput.setText("")
    }

    private fun hasLocationPermission() =
        EasyPermissions.hasPermissions(
            requireContext(),
            android.Manifest.permission.ACCESS_FINE_LOCATION
        )

    private fun requestLocationPermission() {
        EasyPermissions.requestPermissions(
            this,
            "app needs location permission",
            PERMISSION_LOCATION_REQUEST_CODE,
            android.Manifest.permission.ACCESS_FINE_LOCATION
        )
    }

    @SuppressLint("MissingPermission")
    private fun getUserLocation() {
        if (hasLocationPermission()) {
            fusedLocationProviderClient.lastLocation.addOnSuccessListener { location ->
                binding.xInput.setText(location.latitude.toString())
                binding.yInput.setText(location.longitude.toString())
                mapFragment.getMapAsync(this)
            }
        } else {
            requestLocationPermission()
            getUserLocation()
        }
    }

    override fun onPermissionsDenied(requestCode: Int, perms: List<String>) {
        Toast.makeText(requireContext(), "Permission Denied", Toast.LENGTH_SHORT).show()
    }

    override fun onPermissionsGranted(requestCode: Int, perms: List<String>) {
        Toast.makeText(requireContext(), "Permission Granted", Toast.LENGTH_SHORT).show()

    }

    override fun onMapReady(p0: GoogleMap) {
        val latitude = binding.xInput.text.toString().toDouble()
        val longitude = binding.yInput.text.toString().toDouble()
        val myLocation = LatLng(latitude, longitude)
        p0.addMarker(
            MarkerOptions()
                .position(myLocation)
                .title("My location")
        )
        p0.moveCamera(CameraUpdateFactory.newLatLng(myLocation))
        p0.moveCamera(CameraUpdateFactory.zoomTo(11F))
    }

}