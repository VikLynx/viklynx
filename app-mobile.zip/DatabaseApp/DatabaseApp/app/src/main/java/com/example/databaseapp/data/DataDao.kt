package com.example.databaseapp.data

import android.content.ClipData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

import com.example.databaseapp.model.DatabaseModel
import kotlinx.coroutines.flow.Flow

@Dao
interface DataDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(item: DatabaseModel)

    @Query("SELECT * from proposal WHERE id = :id")
    fun getItem(id: Int): Flow<DatabaseModel>

    @Query("SELECT * from proposal ORDER BY name ASC")
    fun getItems(): Flow<List<DatabaseModel>>

    @Query("SELECT * from proposal WHERE name = :name")
    fun getUser(name: String): Flow<List<DatabaseModel>>

}
