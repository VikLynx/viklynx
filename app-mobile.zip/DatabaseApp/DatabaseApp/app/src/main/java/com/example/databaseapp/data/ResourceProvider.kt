package com.example.databaseapp.data

import android.content.Context
import android.net.wifi.WifiManager
import android.os.Build
import android.text.format.Formatter
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity


class ResourceProvider(private val context: Context) {
    fun getIp(): String{
        val wm = context.applicationContext.getSystemService(AppCompatActivity.WIFI_SERVICE) as WifiManager
        val ip = Formatter.formatIpAddress(wm.connectionInfo.ipAddress)
        Log.d("ip z resource:", ip)
        return ip
    }

    fun getDeviceInfo(): String {
        return Build.MANUFACTURER
    }
}