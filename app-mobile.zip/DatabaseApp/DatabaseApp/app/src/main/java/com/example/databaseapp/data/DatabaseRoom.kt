package com.example.databaseapp.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.databaseapp.model.DatabaseModel


@Database(entities = [DatabaseModel::class], version = 1, exportSchema = false)
@TypeConverters(Converters::class)
abstract class DatabaseRoom: RoomDatabase() {
    abstract fun dataDao(): DataDao
    companion object {
        @Volatile
        private var INSTANCE: DatabaseRoom? = null
        fun getDatabase(context: Context): DatabaseRoom {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    DatabaseRoom::class.java,
                    "item_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance.openHelper.writableDatabase
                return instance
            }
        }
    }
}