package com.example.databaseapp.ui

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.Navigation
import com.example.databaseapp.R
import com.example.databaseapp.databinding.FragmentStartBinding


/**
 * A simple [Fragment] subclass.
 * Use the [StartFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class StartFragment : Fragment() {

    private lateinit var binding: FragmentStartBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        binding = FragmentStartBinding.inflate(inflater, container, false)
        binding.infoButton.setOnClickListener { Navigation.findNavController(requireView()).navigate(R.id.action_startFragment_to_appInfo) }
        binding.startButton.setOnClickListener { Navigation.findNavController(requireView()).navigate(R.id.action_startFragment_to_addFragment) }
        binding.CheckButton.setOnClickListener { Navigation.findNavController(requireView()).navigate(R.id.action_startFragment_to_listFragment) }
        return binding.root
    }

}