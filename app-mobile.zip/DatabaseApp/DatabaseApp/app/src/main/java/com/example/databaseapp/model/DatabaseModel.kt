package com.example.databaseapp.model

import android.graphics.Bitmap
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "proposal")
data class DatabaseModel(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val address: String,
    @ColumnInfo(name = "hazardous_waste") val poison: Boolean,
    @ColumnInfo(name = "no_identification") val sweet: Boolean,
    val latitude: String,
    val longitude: String,
    val notes: String,
    val itemPhoto: Bitmap,
    @ColumnInfo(name = "device_ip") val deviceIp: String,
    @ColumnInfo(name = "device_manufacturer") val deviceManufacturer: String
)