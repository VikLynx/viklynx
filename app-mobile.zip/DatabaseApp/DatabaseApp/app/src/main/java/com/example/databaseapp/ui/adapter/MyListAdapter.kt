package com.example.databaseapp.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.databaseapp.databinding.ListItemBinding
import com.example.databaseapp.model.DatabaseModel

class MyListAdapter(private val onItemClicked: (DatabaseModel) -> Unit) :
    ListAdapter<DatabaseModel, MyListAdapter.ViewHolder>(DiffCallback) {
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ViewHolder {
        return ViewHolder(
            ListItemBinding.inflate(LayoutInflater.from(parent.context))
        )


    }
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val current = getItem(position)
        holder.itemView.setOnClickListener {
            onItemClicked(current)
        }
        holder.bind(current)
    }

    class ViewHolder(private var binding: ListItemBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(item: DatabaseModel) {
            binding.apply {
                name.text = item.name
                address.text = item.address
                pickedImage.setImageBitmap(item.itemPhoto)
            }
        }
    }

    companion object {
        private val DiffCallback = object : DiffUtil.ItemCallback<DatabaseModel>() {
            override fun areItemsTheSame(oldItem: DatabaseModel, newItem: DatabaseModel): Boolean {
                return oldItem === newItem
            }

            override fun areContentsTheSame(oldItem: DatabaseModel, newItem: DatabaseModel): Boolean {
                return oldItem.id == newItem.id
            }
        }
    }
}

